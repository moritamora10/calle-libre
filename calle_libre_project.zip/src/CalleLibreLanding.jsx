import React from "react";
import { MapPin, Bus, AlertTriangle, Trophy, Clock, MessageCircle } from "lucide-react";

export default function CalleLibreLanding() {
  return (
    <main className="p-8 space-y-12 bg-gray-50 min-h-screen">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold">🚍 Calle Libre</h1>
        <p className="text-lg text-gray-700">Tu app para moverte sin estrés hacia la Universidad Continental Cusco</p>
      </section>

      <section className="grid md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold">🔍 ¿Cómo funciona?</h2>
          <ul className="list-disc list-inside text-gray-700 space-y-2">
            <li><MapPin className="inline w-5 h-5 text-blue-600" /> Ubicación inteligente</li>
            <li><AlertTriangle className="inline w-5 h-5 text-yellow-600" /> Tráfico en tiempo real</li>
            <li><Bus className="inline w-5 h-5 text-purple-600" /> Horarios dinámicos</li>
            <li><Clock className="inline w-5 h-5 text-green-600" /> Recomendaciones puntuales</li>
            <li><Trophy className="inline w-5 h-5 text-orange-600" /> Racha de puntualidad</li>
            <li><MessageCircle className="inline w-5 h-5 text-pink-600" /> Chatbot académico</li>
          </ul>
        </div>

        <div className="border rounded-lg shadow p-4 bg-white">
          <h3 className="text-xl font-bold mb-2">🌍 Mapa Interactivo</h3>
          <p className="text-sm text-gray-600 mb-4">Visualiza zonas de tráfico y paraderos.</p>
          <div className="bg-gray-200 h-64 flex items-center justify-center">[Mapa aquí]</div>
        </div>
      </section>

      <section className="text-center space-y-4">
        <h2 className="text-2xl font-semibold">💪 ¿Por qué usar Calle Libre?</h2>
        <p className="text-gray-700">✅ Evita el estrés del tráfico.<br />✅ Alertas y reportes.<br />✅ Comunidad estudiantil activa.</p>
        <button className="px-6 py-3 bg-blue-600 text-white rounded-full font-bold hover:bg-blue-700">¡Descárgala Ahora!</button>
      </section>

      <footer className="text-center text-gray-500 text-sm pt-8">
        📩 contacto@callelibre.app | 📱 @CalleLibreApp
      </footer>
    </main>
  );
}